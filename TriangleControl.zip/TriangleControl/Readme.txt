TriangleControl is a game prototyp from Tony Schwensfeier(Antolyt).

Controls(pls use controller):
	A - Submit,
	B - Back,
	left control stick - cursor control,
	start - ingame menu

I strongly recommend to play the game with 2 people.
For a Tutorial see the Tutorial.
There are still some bugs in this version, and its not completely polished.

Sounds from https://freesound.org/

